﻿using Negocio;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

// para abrir archivos
using Microsoft.Win32;
using System.IO;
using Presentacion.Postulante;
using Presentacion.Todo_Empresa;
using Datos;

namespace Presentacion.Empresa
{
    /// <summary>
    /// Lógica de interacción para Solicitudes.xaml
    /// </summary>
    public partial class Solicitudes : Window
    {
        NSolicitudes nSolicitudes = new NSolicitudes();
        NEmpresa nEmpresa = new NEmpresa();
        Datos.Solicitudes solicitudSeleccionado = new Datos.Solicitudes();

         
        public Solicitudes()
        {
            InitializeComponent();
            MostrarSolicitudes(nSolicitudes.ListarTodo_de_Empresa_Actual());
        }

        private void MostrarSolicitudes(List<Datos.Solicitudes> solicitudes)
        {
            dgSolicitudes.ItemsSource = new List<Solicitudes>();    
            dgSolicitudes.ItemsSource = solicitudes;
            lblTotalSolicitudes.Content = solicitudes.Count.ToString();
        }
        private void btnFiltrar_Click(object sender, RoutedEventArgs e)
        {
            if (tbxFiltrar.Text == "")
            {
                MessageBox.Show("Primero ingrese el nombre del puesto de trabajo");
                return;
            }
            MostrarSolicitudes(nSolicitudes.ListarTodoPorFiltro(tbxFiltrar.Text));
        }
        private void dgSolicitudes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            solicitudSeleccionado = dgSolicitudes.SelectedItem as Datos.Solicitudes;
        }

        private void btnQuitarFiltro_Click(object sender, RoutedEventArgs e)
        {
            MostrarSolicitudes(nSolicitudes.ListarTodo_de_Empresa_Actual());
        }

        private void btnVerPostulante_Click(object sender, RoutedEventArgs e)
        {
            if (solicitudSeleccionado == null)
            {
                MessageBox.Show("Primero selccione una solicitud");
                return;
            }
            VerCVPostulante verpostulante = new VerCVPostulante(solicitudSeleccionado);
            verpostulante.ShowDialog();
            MostrarSolicitudes(nSolicitudes.ListarTodo_de_Empresa_Actual());
            lblTotalSolicitudesAceptadas.Content = nSolicitudes.ListarTodo_de_Empresa_Actual().
                               FindAll(t => t.EstadoSolicitud.Equals("Aceptado")).ToList().Count.ToString();

        }
        private void House_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
