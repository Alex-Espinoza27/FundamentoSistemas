﻿using Datos;
using Negocio;
using Presentacion.Empresa;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Presentacion.Todo_Empresa
{
    /// <summary>
    /// Lógica de interacción para HorarioTrabajo.xaml
    /// </summary>
    public partial class HorarioTrabajo : Window
    {
        private NHorarioTrabajo nHorario = new NHorarioTrabajo();
        private Horario_trabajo HorarioSeleccionado = null;
        public delegate void HorarioSeleccionadoDelegate(int horarioId);
        public event HorarioSeleccionadoDelegate HorarioSeleccionadoEvent;
        public HorarioTrabajo()
        {
            InitializeComponent();

            Mostrar(nHorario.ListarTodo());
        }

        private void btnConfirmar_Click(object sender, RoutedEventArgs e)
        {
            if (tbDia.Text == "" || tbHoraInicio.Text == "" || TbHoraFin.Text == "")
            {
                MessageBox.Show("Ingrese todos los campos requeridos");
                return;
            }

            //Creando objeto Horario Trabajo
            Horario_trabajo horario_Trabajo = new Horario_trabajo
            {
                Dia = tbDia.Text,
                Hora_inicio = DateTime.Parse(tbHoraInicio.Text).TimeOfDay,
                Hora_fin = DateTime.Parse(TbHoraFin.Text).TimeOfDay,
            };

            string resultado = nHorario.RegistrarHorario(horario_Trabajo);
            MessageBox.Show(resultado);
            Mostrar(nHorario.ListarTodo());
        }
        private void Mostrar(List<Horario_trabajo> horario_Trabajos)
        {
            dgHorariosTrabajo.ItemsSource = horario_Trabajos;
        }
        

        private void dgHorariosTrabajos_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            HorarioSeleccionado = dgHorariosTrabajo.SelectedItem as Horario_trabajo;
            HorarioSeleccionadoEvent?.Invoke(HorarioSeleccionado.HorarioID);
            this.Close();
        }

        private void House_Click(object sender, RoutedEventArgs e)
        {
            RegistrarPuestos registrarPuestos = new RegistrarPuestos();
            registrarPuestos.ShowDialog();
        }

        private void VerSolicitudes_Click(object sender, RoutedEventArgs e)
        {
            EmpresaPrincipal empresaPrincipal = new EmpresaPrincipal();
            empresaPrincipal.Show();
        }
    }
}
