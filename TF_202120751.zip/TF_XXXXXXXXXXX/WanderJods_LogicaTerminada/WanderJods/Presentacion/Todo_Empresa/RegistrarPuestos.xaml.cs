﻿using Datos;
using Negocio;
using Presentacion.Todo_Empresa;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Presentacion.Empresa
{
    /// <summary>
    /// Lógica de interacción para RegistrarPuestos.xaml
    /// </summary>
    public partial class RegistrarPuestos : Window
    {
        private NOfertaEmpleo nOferta = new NOfertaEmpleo();
        private Oferta_Empleo OfertaSeleccionada = null;
        private NHorarioTrabajo nHorario = new NHorarioTrabajo();
        public RegistrarPuestos()
        {
            InitializeComponent();
            Mostrar(nOferta.ListarTodo_EmpresaIngresante());
        }
        private void Mostrar(List<Oferta_Empleo> oferta_Empleos)
        {
            dgOfertas_Empleo.ItemsSource = new List<Oferta_Empleo>();
            dgOfertas_Empleo.ItemsSource = oferta_Empleos;
            lblTotalPuestosTrabajo.Content = (dgOfertas_Empleo.Items.Count-1).ToString();
        }

        private void btnRegistrarOferta_Click(object sender, RoutedEventArgs e)
        {
            if (DtFechaP.SelectedDate == null || DtFechaV.SelectedDate == null || tbHorarioTrabajo.Text == "" || tbNombreOferta.Text == "" || cbIndicador.Text == "" || cbTipoTrabajo.Text == "" || tbDescripcion.Text == "" || tbSueldo.Text == "")
            {
                MessageBox.Show("Ingrese los campos requeridos");
            }

            bool Indicador = false;

            if (cbIndicador.Text == "Activo")
            {
                Indicador = true;
            }

            //Creando Objeto
            Oferta_Empleo oferta = new Oferta_Empleo
            {
                EmpresaID = Datos.DEmpresa.Empresa_Ingresante.EmpresaID,
                Nombre_Empresa = Datos.DEmpresa.Empresa_Ingresante.Nombre_Empresa,
                Titulo_Trabajo = tbNombreOferta.Text,
                Descripcion = tbDescripcion.Text,
                Salario = decimal.Parse(tbSueldo.Text),
                Tipo_Trabajo = cbTipoTrabajo.Text,
                Fecha_publicacion = DtFechaP.SelectedDate.Value,
                Fecha_vencimiento = DtFechaV.SelectedDate.Value,
                HorarioID = int.Parse(tbHorarioTrabajo.Text),
                ind_Activo = Indicador,
            };

            string resultado = nOferta.RegistrarOferta_Empleo(oferta);
            MessageBox.Show(resultado);
            

            tbNombreOferta.Clear();
            tbDescripcion.Clear();
            tbSueldo.Clear();
            tbHorarioTrabajo.Clear();

            Mostrar(nOferta.ListarTodo_EmpresaIngresante());

        }
        private void HorarioSeleccionadoHandler(int horarioId)
        {
            tbHorarioTrabajo.Text = horarioId.ToString();
        }
        private void btnVerHorarios_Click(object sender, RoutedEventArgs e)
        {
            HorarioTrabajo horarios = new HorarioTrabajo();
            horarios.HorarioSeleccionadoEvent += HorarioSeleccionadoHandler;
            horarios.ShowDialog();  
        }
        private void dgOfertasAct_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            OfertaSeleccionada = dgOfertas_Empleo.SelectedItem as Oferta_Empleo;
        }
        private void House_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnInavilitar_Click(object sender, RoutedEventArgs e)
        {
            if (OfertaSeleccionada == null)
            {
                MessageBox.Show("Primero seleccione el libro");
                return;
            }
            String mensaje = nOferta.inhabilitarPuesto(OfertaSeleccionada.OfertaID);
            MessageBox.Show(mensaje);

            Mostrar(nOferta.ListarTodo_EmpresaIngresante());
        }
    }
}
