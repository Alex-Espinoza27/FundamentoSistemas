﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Datos;
using Negocio;

namespace Presentacion.Empresa
{
    /// <summary>
    /// Lógica de interacción para EmpresaPrincipal.xaml
    /// </summary>
    public partial class EmpresaPrincipal : Window
    {
        private NEmpresa nEmpresa = new NEmpresa();

        public EmpresaPrincipal()
        {
            InitializeComponent();
            if (Datos.DEmpresa.Empresa_Ingresante != null)
            {
                btnConfirmarRegistro.IsEnabled = false;
            }
            Mostrar();
        }

        private void Mostrar()
        {
            if (Datos.DEmpresa.Empresa_Ingresante != null)
            {
                tbNombre.Text = Datos.DEmpresa.Empresa_Ingresante.Nombre_Empresa;
                tbCorreo.Text = Datos.DEmpresa.Empresa_Ingresante.Correo;
                tbTelefono.Text = Datos.DEmpresa.Empresa_Ingresante.Telefono;
                tbRUC.Text = Datos.DEmpresa.Empresa_Ingresante.RUC;
                cbRubro.Text = Datos.DEmpresa.Empresa_Ingresante.Rubro;
            }
        }

        private void btnConfirmarRegistro_Click(object sender, RoutedEventArgs e)
        {

            if (Datos.DEmpresa.Empresa_Ingresante != null)
            {
                btnConfirmarRegistro.IsEnabled = false;
                return;
            }
            if (tbNombre.Text == "" || tbCorreo.Text == "" || tbTelefono.Text == "" || cbRubro.Text == "" || tbRUC.Text == "")
            {
                MessageBox.Show("Ingrese todos los campos requeridos");
                return;
            }
            Datos.Empresa empresa = new Datos.Empresa
            {
                UsuarioID = Datos.DUsuario.Usuario_Empresa.UsuarioID,
                Nombre_Empresa = tbNombre.Text,
                Correo = tbCorreo.Text,
                Telefono = tbTelefono.Text,
                Rubro = cbRubro.Text,
                RUC = tbRUC.Text,
            };
            String resultado = nEmpresa.RegistrarNuevaEmpresa(empresa);
            MessageBox.Show(resultado);
        }
        private void btnVerPostulantes_Click(object sender, RoutedEventArgs e)
        {
            if (Datos.DEmpresa.Empresa_Ingresante == null)
            {
                MessageBox.Show("Primero ingresa tus datos personales");
                return;
            }
            Solicitudes solicitudes = new Solicitudes();
            this.Hide();
            solicitudes.ShowDialog();
            this.Show();
        }

        private void btnOfertas_Empleo_Click(object sender, RoutedEventArgs e)
        {
            if (Datos.DEmpresa.Empresa_Ingresante == null)
            {
                MessageBox.Show("Primero ingresa tus datos personales");
                return;
            }
            this.Hide();
            RegistrarPuestos registrarPuestos = new RegistrarPuestos();
            registrarPuestos.ShowDialog();
            this.Show();
        } 
        private void btnCerrarSesion_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        private void btnActualizarDatos_Click(object sender, RoutedEventArgs e)
        {
            if (tbNombre.Text == "" || tbCorreo.Text == "" || tbTelefono.Text == "" || cbRubro.Text == "" || tbRUC.Text == "")
            {
                MessageBox.Show("Ingrese todos los campos requeridos");
                return;
            }
            Datos.Empresa empresa = new Datos.Empresa
            {
                UsuarioID = Datos.DUsuario.Usuario_Empresa.UsuarioID,
                Nombre_Empresa = tbNombre.Text,
                Correo = tbCorreo.Text,
                Telefono = tbTelefono.Text,
                Rubro = cbRubro.Text,
                RUC = tbRUC.Text,
            };
            String resultado = nEmpresa.ActualizarDatos(empresa);
            MessageBox.Show(resultado);
        }
    }
}


