﻿using Negocio;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


// para abrir archivos
using Microsoft.Win32;
using System.IO;  
using System.Runtime.Versioning;

namespace Presentacion.Todo_Empresa
{
    /// <summary>
    /// Lógica de interacción para VerCVPostulante.xaml
    /// </summary>
    public partial class VerCVPostulante : Window
    {
        NSolicitudes nSolicitudes = new NSolicitudes();
        NPostulante nPostulante = new NPostulante();
        Datos.Solicitudes solicitudSeleccionado = new Datos.Solicitudes();

        public VerCVPostulante(Datos.Solicitudes solicitudSeleccionado)
        {
            InitializeComponent();
            this.solicitudSeleccionado = solicitudSeleccionado;
            MostrarDatos();
        }
        private void MostrarDatos()
        {

            Datos.Postulante postulateSelec = nPostulante.listarTodo().Find(e => e.PostulanteID.Equals(solicitudSeleccionado.PostulanteID));

            tbxNombre.Text = postulateSelec.Nombre;
            tbxTelefono.Text = postulateSelec.Telefono;
            tbxCorreo.Text = postulateSelec.Correo;
            tbxFechaNacimiento.Text = postulateSelec.FechaNacimiento.ToString();
            tbxDireccion.Text = postulateSelec.Direccion;
            tbxPuestoSolicitado.Text= solicitudSeleccionado.Titulo_Trabajo.ToString();

            // Mostrar la foto en el bitmapImage
            BitmapImage bitmapImage = new BitmapImage();
            bitmapImage.BeginInit();
            bitmapImage.StreamSource = new MemoryStream(postulateSelec.Foto);
            bitmapImage.EndInit();
            imgPostulante.Source = bitmapImage;
        }

        private void btnVerCV_Click(object sender, RoutedEventArgs e)
        {
            byte[] archivoBytes = nSolicitudes.VerCVPostulante(solicitudSeleccionado.PostulanteID);
            //Guarda temporalmente el archivo PDF en el sistema de archivos
            String rutaTemporal = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "temp.pdf");
            File.WriteAllBytes(rutaTemporal, archivoBytes);
            Process.Start(rutaTemporal);
        }

        private void btnAcptarSolicitud_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(solicitudSeleccionado.PostulanteID.ToString());
            String mensaje = nSolicitudes.AceptarSolicitud(solicitudSeleccionado);
            MessageBox.Show(mensaje);

        }

        private void btnSalair_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
