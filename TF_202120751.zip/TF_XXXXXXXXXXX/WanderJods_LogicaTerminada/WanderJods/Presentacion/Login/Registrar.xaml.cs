﻿using Datos;
using Negocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;



namespace Presentacion.Login
{
    /// <summary>
    /// Lógica de interacción para Registrar.xaml
    /// </summary>
    public partial class Registrar : Window
    {
        private NUsuario nUsuario = new NUsuario();
        public Registrar()
        {
            InitializeComponent();
        }

        private string SecureStringToString(SecureString secureString)
        {
            if (secureString == null)
                return string.Empty;
            IntPtr unmanagedString = IntPtr.Zero;
            try
            {
                unmanagedString = Marshal.SecureStringToGlobalAllocUnicode(secureString);
                return Marshal.PtrToStringUni(unmanagedString);
            }
            finally
            {
                Marshal.ZeroFreeGlobalAllocUnicode(unmanagedString);
            }
        }

        private void tbnConfirmar_Click(object sender, RoutedEventArgs e)
        {
            // validacion de campo
            if (tbContraseña.Password == "" || tbUsuario.Text == "" || cbTipoUsuario.Text == "")
            {
                MessageBox.Show("Ingrese todos los campos");
                return;
            }


            // dessencriptar la contraseña a String
            string password = SecureStringToString(tbContraseña.SecurePassword);

            // crear objeto
            Usuario usuario = new Usuario
            {
                Nombre_usuario = tbUsuario.Text,
                Contrasena = password,
                TipoUsuario = cbTipoUsuario.Text
            };

           

            bool existe = nUsuario.ExisteNombreUsuario(tbUsuario.Text);
            if (existe)
            {
                MessageBox.Show("El nombre ya existe eliga otro nombre :)");
                return;
            }
            else if (existe == false)
            {
                String mensaje = nUsuario.Registrar(usuario);
                MessageBox.Show(mensaje);
            }
        }
        private void tbnVolver_Click(object sender, RoutedEventArgs e)
        {
            
            this.Close();
        }
    }
}
