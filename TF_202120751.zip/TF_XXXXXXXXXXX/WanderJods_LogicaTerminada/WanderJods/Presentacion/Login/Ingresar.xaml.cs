﻿using Datos;
using Negocio;
using Presentacion.Postulante;
using Presentacion.Empresa;
using Presentacion.Login;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


using System.Runtime.InteropServices;
using System.Security;



namespace Presentacion.Login
{
    /// <summary>
    /// Lógica de interacción para Login.xaml
    /// </summary>
    public partial class Ingresar : Window
    {
        private NUsuario nUsuario = new NUsuario();
        public Ingresar()
        {
            InitializeComponent();
        }

        // para convertir la contraseña a string de SecureString
        private string SecureStringToString(SecureString secureString)
        {
            if (secureString == null)
                return string.Empty;
            IntPtr unmanagedString = IntPtr.Zero;
            try
            {
                unmanagedString = Marshal.SecureStringToGlobalAllocUnicode(secureString);
                return Marshal.PtrToStringUni(unmanagedString);
            }
            finally
            {
                Marshal.ZeroFreeGlobalAllocUnicode(unmanagedString);
            }
        }

        private void btnIniciarSesion_Click_1(object sender, RoutedEventArgs e)
        {
            if (tbContrasena.Password == "" || tbUsuario.Text == "" || cbTipoUsuario.Text == "")
            {
                MessageBox.Show("Ingrese todos los campos");
                return;
            }
            
            // dessencriptar la contraseña a String
            string password = SecureStringToString(tbContrasena.SecurePassword);

            Usuario usuario = new Usuario
            {
                Nombre_usuario = tbUsuario.Text,
                Contrasena = password,
                TipoUsuario = cbTipoUsuario.Text
            };
            bool existe = nUsuario.ExisteUsuario(usuario);

            if (existe)
            {
                 
                if (cbTipoUsuario.Text == "Postulante")
                {
                    this.Hide();
                    PostulantePrincipal postulante = new PostulantePrincipal();
                    postulante.ShowDialog();
                    this.Hide();

                }
                else
                {
                    this.Hide();
                    EmpresaPrincipal empresa = new EmpresaPrincipal();
                    empresa.ShowDialog();
                    this.Hide();

                }
            }
            else
            {
                MessageBox.Show("Usuario y/o Contraseñas invalidos, por favor vuelva a ingresar sus credenciales");
            }
            this.Show();
        }
        private void btnRegistrarse_Click(object sender, RoutedEventArgs e)
        {

            Registrar registrar = new Registrar();
            this.Hide();
            registrar.ShowDialog();
            this.Show();
        }
    }
}
