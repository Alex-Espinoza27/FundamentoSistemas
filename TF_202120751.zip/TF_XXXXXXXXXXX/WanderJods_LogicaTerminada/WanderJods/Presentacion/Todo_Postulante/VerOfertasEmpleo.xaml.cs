﻿using Datos;
using Negocio;
using Presentacion.Empresa;
using Presentacion.Todo_Postulante;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Presentacion.Postulante
{
    /// <summary>
    /// Lógica de interacción para VerOfertasEmpleo.xaml
    /// </summary>
    public partial class VerOfertasEmpleo : Window
    {
        NOfertaEmpleo nOfertasEmpleo = new NOfertaEmpleo();

        NEmpresa nEmpresas = new NEmpresa(); 
        Oferta_Empleo ofertaSeleccionado = null;


        public VerOfertasEmpleo()
        {
            InitializeComponent();
            MostrarEmpleos(nOfertasEmpleo.ListarTodo());
        }

        private void MostrarEmpleos(List<Oferta_Empleo> ofertas)
        {
            dgOfertasEmpleo.ItemsSource = new List<Oferta_Empleo>();
            dgOfertasEmpleo.ItemsSource = ofertas;
            lblTotalSolicitudes.Content = ofertas.Count.ToString();
        }

        private void tbEnviarSolicitud_Click(object sender, RoutedEventArgs e)
        {

            if (Datos.DPostulante.Postulante_Ingresante == null)
            {
                MessageBox.Show("Primero Registra tus datos personales Antes de continuar");
                return;
            }
            if (ofertaSeleccionado == null)
            {
                MessageBox.Show("Primero seleccione la oferta de empleo");
                return;
            }
            if(ofertaSeleccionado.ind_Activo == false)
            {
                MessageBox.Show("Ya no es posible enviar solicitud a este puesto de trabajo");
                return;
            }
            VerDetalleOfertaEmpleo ver = new VerDetalleOfertaEmpleo(ofertaSeleccionado);
            ver.ShowDialog();

            MostrarEmpleos(nOfertasEmpleo.ListarTodo());
        }
        private void btnBuscarFiltro_Click(object sender, RoutedEventArgs e)
        {
            if(tbFiltroNombrePuesto.Text == "")
            {
                MessageBox.Show("Primero ingrese el valor a filtrar");
                return;
            }
            MostrarEmpleos(nOfertasEmpleo.FiltrarOfertasPorNombre(tbFiltroNombrePuesto.Text));

        }
        private void dgOfertasEmpleo_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            ofertaSeleccionado = dgOfertasEmpleo.SelectedItem as Oferta_Empleo;

        }

        private void House_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            dgOfertasEmpleo.SelectedItem = null;
            ofertaSeleccionado = null;
        }
        private void btnLimpiar_Click(object sender, RoutedEventArgs e)
        {
            MostrarEmpleos(nOfertasEmpleo.ListarTodo());
        }
    }
}
