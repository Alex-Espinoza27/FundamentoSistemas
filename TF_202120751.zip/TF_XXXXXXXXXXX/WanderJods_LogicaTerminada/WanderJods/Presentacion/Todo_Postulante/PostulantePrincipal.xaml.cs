﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


using Datos;
using Negocio;


// para abrir archivos
using Microsoft.Win32;



namespace Presentacion.Postulante
{
    /// <summary>
    /// Lógica de interacción para PostulantePrincipal.xaml
    /// </summary>
    public partial class PostulantePrincipal : Window
    {
        
        public static String direccionFoto = "";
        public static String direccionArchivo = "";
        private NPostulante nPostulante = new NPostulante();

        public PostulantePrincipal()
        {
            InitializeComponent();
            lblMiPerfil.Content = DUsuario.Usuario_Postulante.Nombre_usuario;
            if (Datos.DPostulante.Postulante_Ingresante != null)
            {
                btnGuardarDatos.IsEnabled = false;
            }
            MostrarDatosAlPrincio();
        }
        private void MostrarDatosAlPrincio()
        {
            if (Datos.DPostulante.Postulante_Ingresante != null)
            {
                tbNombre.Text = Datos.DPostulante.Postulante_Ingresante.Nombre;
                tbCorreo.Text = Datos.DPostulante.Postulante_Ingresante.Correo;
                tbTelefono.Text = Datos.DPostulante.Postulante_Ingresante.Telefono;

                // Mostrar la foto en el bitmapImage
                BitmapImage bitmapImage = new BitmapImage();
                bitmapImage.BeginInit();
                bitmapImage.StreamSource = new MemoryStream(Datos.DPostulante.Postulante_Ingresante.Foto);
                bitmapImage.EndInit();
                imgPostulante.Source = bitmapImage;
            }
        }

        private byte[] ConvertirImagenArchivoABytes(String rutaArchivo_imagen)
        {
           
            byte[] archivoImagenData;

            using (FileStream fs = new FileStream(rutaArchivo_imagen, FileMode.Open, FileAccess.Read))
            {
                using (BinaryReader br = new BinaryReader(fs))
                {
                    archivoImagenData = br.ReadBytes((int)fs.Length);
                }
            }

            return archivoImagenData;
        }

        private void tbnCargar_Click(object sender, RoutedEventArgs e)
        {
            // abre la carpeta para seleccionar imagen y el objeto contiene la imagen
            OpenFileDialog abrirCarpeta = new OpenFileDialog();

            abrirCarpeta.Filter = "Archivos de imagen|*.png;*.jpg";
            // si se selecciono y puso aceptar
            if(abrirCarpeta.ShowDialog() == true)
            {
                // guardamos la direccion de la imegen
                Uri fileUri = new Uri(abrirCarpeta.FileName);

                // asignamos la imagen al imgPostulante
                imgPostulante.Source = new BitmapImage(fileUri);

                // guardar la direccion de la imagen
                direccionFoto = abrirCarpeta.FileName; 

            }
        }
 

        private void btnActualizarDatos_Click(object sender, RoutedEventArgs e)
        {
            if (tbNombre.Text == "" || tbCorreo.Text == "" || tbTelefono.Text == "" ||
               imgPostulante.Source == null || lblDireccionArchivo.Content.ToString() == "" 
               || tbDireccion.Text =="" || DtFechaNacimiento.SelectedDate == null )
            {
                MessageBox.Show("ingrese todos los datos y seleccione los archivos");
                return;
            }
            byte[] imagBytes = ConvertirImagenArchivoABytes(direccionFoto); 
            byte[] archivoBytes = ConvertirImagenArchivoABytes(direccionArchivo); 

            Datos.Postulante postulanteNuevo = new Datos.Postulante
            {
                PostulanteID = Datos.DPostulante.Postulante_Ingresante.PostulanteID,
                Nombre = tbNombre.Text,
                UsuarioID = Datos.DUsuario.Usuario_Postulante.UsuarioID,
                Foto = imagBytes,
                CV = archivoBytes,
                Correo = tbCorreo.Text,
                Telefono = tbTelefono.Text,
                FechaNacimiento = DtFechaNacimiento.SelectedDate.Value,
                Direccion = tbDireccion.Text
            };
             
            String mensaje = nPostulante.Registrar(postulanteNuevo);
            MessageBox.Show(mensaje);
        }

        private void btnGuardarDatos_Click(object sender, RoutedEventArgs e)
        {
            if (Datos.DPostulante.Postulante_Ingresante != null)
            {
                btnGuardarDatos.IsEnabled = false;
                return;
            }

            if (tbNombre.Text == "" || tbCorreo.Text == "" || tbTelefono.Text == "" ||
               imgPostulante.Source == null || lblDireccionArchivo.Content.ToString() == "" ||
                tbDireccion.Text == "" || DtFechaNacimiento.SelectedDate == null)
            {
                MessageBox.Show("ingrese todos los datos y seleccione los archivos");
                return;
            }
 
            byte[] imagBytes = ConvertirImagenArchivoABytes(direccionFoto);
            byte[] archivoBytes = ConvertirImagenArchivoABytes(direccionArchivo);


            Datos.Postulante postulanteNuevo = new Datos.Postulante
            {
  
                Nombre = tbNombre.Text,
                UsuarioID = Datos.DUsuario.Usuario_Postulante.UsuarioID,
                Foto = imagBytes,
                CV = archivoBytes,
                Correo = tbCorreo.Text,
                Telefono = tbTelefono.Text,
                FechaNacimiento = DtFechaNacimiento.SelectedDate.Value,
                Direccion = tbDireccion.Text
            };




            String mensaje = nPostulante.Registrar(postulanteNuevo);
            MessageBox.Show(mensaje);
        }

        private void PVerOferta_Click(object sender, RoutedEventArgs e)
        {
            if (Datos.DPostulante.Postulante_Ingresante == null)
            {
                MessageBox.Show("Primero ingresa tus datos personales");
                return;
            }

            this.Hide();
            VerOfertasEmpleo ofertas = new VerOfertasEmpleo();
            ofertas.ShowDialog();
            this.Show();
        }
        private void PHistorialPostulaciones_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            HistorialPostulaciones historial = new HistorialPostulaciones();
            historial.ShowDialog();
            this.Show();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        private void tbnCargar_CV_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Archivos PDF (*.pdf)|*.pdf";

            if (openFileDialog.ShowDialog() == true)
            {
                // Obtiene la dirección del archivo seleccionado
                direccionArchivo = openFileDialog.FileName;
                // Puedes mostrar la ruta en un control de texto o etiqueta si es necesario
                lblDireccionArchivo.Content = direccionArchivo;
            }
        }
    }
}
