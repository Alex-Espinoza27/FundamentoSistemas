﻿using Negocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Presentacion.Todo_Postulante
{
    /// <summary>
    /// Lógica de interacción para VerDetalleOfertaEmpleo.xaml
    /// </summary>
    public partial class VerDetalleOfertaEmpleo : Window
    {
        Datos.Oferta_Empleo ofertaSelec = new Datos.Oferta_Empleo();
        NSolicitudes nSolicitudes = new NSolicitudes();
        NHistorialSolicitudes nHistorialSolicitudes = new NHistorialSolicitudes();
        NEmpresa nEmpresa = new NEmpresa();

        public VerDetalleOfertaEmpleo(Datos.Oferta_Empleo ofertaSelec)
        {
            InitializeComponent();
            this.ofertaSelec = ofertaSelec;
            MostrarDatos();
        }

        public void MostrarDatos()
        {
            Datos.Empresa empresa = nEmpresa.ListarTodo().Find(t=>t.EmpresaID.Equals(ofertaSelec.EmpresaID));
            tbxNombreEmpresa.Text = empresa.Nombre_Empresa;
            tbxRubro.Text = empresa.Rubro;
            tbxRUC.Text = empresa.RUC;
            tbxCorreo.Text = empresa.Correo;
            tbxTelefono.Text = empresa.Telefono;

            tbxNombreOferta.Text = ofertaSelec.Titulo_Trabajo;
            tbxDetalleOferta.Text = ofertaSelec.Descripcion;
            tbxTipotrabajoOferta.Text = ofertaSelec.Tipo_Trabajo;
            tbxSalario.Text = ofertaSelec.Salario.ToString();
            tbxFechaVencimiento.Text = ofertaSelec.Fecha_vencimiento.ToString();
            tbxFechaPublicacion.Text = ofertaSelec.Fecha_publicacion.ToString();
            tbxEstadoOferta.Text = ofertaSelec.ind_Activo.ToString();
        }

        private void btnEnviarSolicitud_Click(object sender, RoutedEventArgs e)
        {
            DateTime fechaActual = DateTime.Now;

            Datos.Solicitudes solicitudNueva = new Datos.Solicitudes
            {
                PostulanteID = Datos.DPostulante.Postulante_Ingresante.PostulanteID,
                OfertaID = ofertaSelec.OfertaID,
                Titulo_Trabajo = ofertaSelec.Titulo_Trabajo,
                FechaSolicitud = fechaActual,
                EstadoSolicitud = "Por definirse"
            };
            String mensaje = nSolicitudes.RegistrarSolicitud(solicitudNueva);
            MessageBox.Show(mensaje);


            // buscar de nuevo la solicitud generada enteriormeten para encontrar su ID
            Datos.Solicitudes solicitudGenerada = nSolicitudes.ListarTodo().Find(a => a.PostulanteID.Equals(solicitudNueva.PostulanteID)
                                                                                 && a.OfertaID.Equals(ofertaSelec.OfertaID));

            Datos.Historial_Solicitudes historial = new Datos.Historial_Solicitudes
            {
                SolicitudID = solicitudGenerada.SolicitudID,
                PostulanteID = Datos.DPostulante.Postulante_Ingresante.PostulanteID,
                Nombre_Empresa = ofertaSelec.Nombre_Empresa,
                Titulo_Trabajo = ofertaSelec.Titulo_Trabajo,
                FechaSolicitud = fechaActual,
                EstadoSolicitud = "Por definirse"
            };

            nHistorialSolicitudes.RegistrarHistorial(historial);
        }
        private void btnSalir_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
