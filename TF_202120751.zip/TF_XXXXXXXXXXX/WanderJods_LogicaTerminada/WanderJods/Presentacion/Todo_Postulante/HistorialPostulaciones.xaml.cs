﻿using Negocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Presentacion.Postulante
{
    /// <summary>
    /// Lógica de interacción para HistorialPostulaciones.xaml
    /// </summary>
    public partial class HistorialPostulaciones : Window
    {
        private NHistorialSolicitudes nHistorialSoli = new NHistorialSolicitudes();
        Datos.Historial_Solicitudes historialSeleccionado = null;
        public HistorialPostulaciones()
        {
            InitializeComponent();
            Mostrar(nHistorialSoli.ListarTodo());
        }

        private void Mostrar(List<Datos.Historial_Solicitudes> historiales)
        {
            dgHistorial.ItemsSource = new List<Datos.Historial_Solicitudes>();
            dgHistorial.ItemsSource = historiales;
            lblTotalSolicitudes.Content = historiales.Count.ToString();

        }
        private void btnBuscar_Click(object sender, RoutedEventArgs e)
        {
            if(tbxFiltroPorPuestoEmpleo.Text == "")
            {
                MessageBox.Show("Ingrese el valor a buscar");
                return;
            }
            Mostrar(nHistorialSoli.ListarTodoPorFiltro(tbxFiltroPorPuestoEmpleo.Text));
        }

        private void dgHistorial_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            historialSeleccionado = dgHistorial.SelectedItem as Datos.Historial_Solicitudes;
        }
        private void btnEliminar_Click(object sender, RoutedEventArgs e)
        {
            if(historialSeleccionado == null)
            {
                MessageBox.Show("Primero seleccione un historial");
                return;
            }
            String mensaje = nHistorialSoli.EliminarHistorial(historialSeleccionado.HistorialID);
            MessageBox.Show(mensaje);
            Mostrar(nHistorialSoli.ListarTodo());
        }
        private void btnLimpiar_Click(object sender, RoutedEventArgs e)
        {
            Mostrar(nHistorialSoli.ListarTodo());
        }

        private void btnHouse_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
