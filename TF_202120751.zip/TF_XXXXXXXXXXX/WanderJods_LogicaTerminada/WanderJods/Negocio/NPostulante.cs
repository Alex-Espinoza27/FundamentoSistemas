﻿using Datos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class NPostulante
    {
        private DPostulante dPostulante = new DPostulante();
        public NPostulante() { }

        public String Registrar(Postulante postulante)
        {
            return dPostulante.Registrar(postulante);
        }
        public String Modificar(Postulante postulante)
        {
            return dPostulante.Modificar(postulante);
        }
        public List<Postulante> listarTodo()
        {
            return dPostulante.ListarTodo();
        }

    }
}
