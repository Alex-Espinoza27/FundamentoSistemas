﻿using Datos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class NHistorialSolicitudes
    {
        DHistorialSolicitudes dHistoriales = new DHistorialSolicitudes();
        NSolicitudes nSolicitudes = new NSolicitudes(); 
        public NHistorialSolicitudes() { }
        public void RegistrarHistorial(Historial_Solicitudes historial)
        {
            dHistoriales.RegistrarHistorial(historial);
        }

        public String EliminarHistorial(int id)
        {
            return dHistoriales.EliminarHistorial(id);
        }

        public List<Historial_Solicitudes> ListarTodo()
        {
            return dHistoriales.ListarTodo().FindAll(p=>p.PostulanteID.Equals(Datos.DPostulante.Postulante_Ingresante.PostulanteID));
        }
        public List<Historial_Solicitudes> ListarTodoPorFiltro(String PuestoTrabajo)
        { 
            return dHistoriales.ListarTodo().FindAll(a=>a.Titulo_Trabajo.Equals(PuestoTrabajo));
        }
    }
}
