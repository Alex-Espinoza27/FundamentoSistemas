﻿using Datos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class NOfertaEmpleo
    {
        private DOfertaEmpleo dOferta = new DOfertaEmpleo();
        public NOfertaEmpleo() { }

        public string RegistrarOferta_Empleo(Oferta_Empleo oferta_Empleo)
        {
            return dOferta.CrearOfertaEmpleo(oferta_Empleo);
        }

        public string EliminarOferta_Empleo(int id)
        {
            return dOferta.EliminarOferta(id);
        }

        public string inhabilitarPuesto(int id)
        {
            return dOferta.inhabilitarPuesto(id);
        }

        public List<Oferta_Empleo> ListarTodo()
        {
            return dOferta.ListarTodo();
        }
        public List<Oferta_Empleo> ListarTodo_EmpresaIngresante()
        {
            return  ListarTodo().FindAll(p=>p.EmpresaID.Equals(Datos.DEmpresa.Empresa_Ingresante.EmpresaID));
        }
        public List<Oferta_Empleo> FiltrarOfertasPorNombre(String nombrePuesto)
        {
            return dOferta.ListarTodo().FindAll(e => e.Titulo_Trabajo.Equals(nombrePuesto));
        }
    }
}
