﻿using Datos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class NUsuario
    {
        private DUsuario dUsuario = new DUsuario();
        public NUsuario() { }

        public bool ExisteUsuario(Usuario usuario)
        {
           return dUsuario.ExisteUsuario(usuario);
        }
        public bool ExisteNombreUsuario(String nombre)
        {
            return dUsuario.ExisteNombreUsuario(nombre);
        }
        public String Registrar(Usuario usuario)
        {
            return dUsuario.Registrar(usuario);
        }
    }
}
