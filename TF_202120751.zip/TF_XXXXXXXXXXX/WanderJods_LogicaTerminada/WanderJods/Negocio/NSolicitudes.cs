﻿using Datos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class NSolicitudes
    {
        DSolicitudes dSolicitudes = new DSolicitudes();
        NPostulante nPostulante = new NPostulante();
        NOfertaEmpleo nOfertsEmpleo = new NOfertaEmpleo();
        public NSolicitudes() { }

        public String RegistrarSolicitud(Solicitudes soli)
        {
            return dSolicitudes.RegistrarSolicitud(soli);
        }
        public List<Solicitudes> ListarTodo()
        {
            return dSolicitudes.ListarTodo();
        }
        public List<Solicitudes> ListarTodo_de_Empresa_Actual()
        {
            List<Solicitudes> solicitudesDe_Esta_Empresa = new List<Solicitudes>();
            // ofertas de la empresa ingresante
            List<Oferta_Empleo> empleos = nOfertsEmpleo.ListarTodo_EmpresaIngresante();
            // Listar las solicitudes de estas ofertas
            foreach (Oferta_Empleo item in empleos)
            {
                solicitudesDe_Esta_Empresa.AddRange(ListarTodo().FindAll(r => r.OfertaID.Equals(item.OfertaID)));
            }
            return solicitudesDe_Esta_Empresa;
        }
        public List<Solicitudes> ListarTodoPorFiltro(String NombrePuesto)
        {
            return ListarTodo_de_Empresa_Actual().FindAll(e =>e.Titulo_Trabajo.Equals( NombrePuesto));
        }
        public String AceptarSolicitud(Solicitudes soliAceptado)
        {
            return dSolicitudes.AceptarSolicitud( soliAceptado);
        }
        public byte[] VerCVPostulante(int id)
        {
            return dSolicitudes.VerCVPostulante(id);
        }
        
    }
}
