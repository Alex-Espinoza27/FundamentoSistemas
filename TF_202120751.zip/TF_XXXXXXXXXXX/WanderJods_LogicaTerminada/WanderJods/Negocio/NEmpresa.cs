﻿using Datos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class NEmpresa
    {
        private DEmpresa dEmpresa = new DEmpresa();
        public String RegistrarNuevaEmpresa(Empresa empresa)
        {
            return dEmpresa.RegistrarEmpresa(empresa);
        }
        public String ActualizarDatos(Empresa empresa)
        {
            return dEmpresa.ActualizarDatos(empresa);
        }
        public List<Empresa> ListarTodo()
        {
            return dEmpresa.ListarTodo();
        }
    }
}

