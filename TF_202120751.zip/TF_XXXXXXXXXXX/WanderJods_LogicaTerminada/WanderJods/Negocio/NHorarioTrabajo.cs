﻿using Datos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class NHorarioTrabajo
    {
        private DHorarioTrabajo dHorario = new DHorarioTrabajo();
        public NHorarioTrabajo() { }
        public String RegistrarHorario(Horario_trabajo horario_Trabajo)
        {
            return dHorario.RegistrarHorario(horario_Trabajo);
        }
        public String EliminarHorario(int id)
        {
            return dHorario.Eliminar(id);
        }
        public List<Horario_trabajo> ListarTodo()
        {
            return dHorario.ListarTodo();
        }
    }
}
