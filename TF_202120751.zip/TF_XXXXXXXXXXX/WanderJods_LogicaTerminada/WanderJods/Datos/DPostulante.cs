﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class DPostulante
    {
        public static Postulante Postulante_Ingresante;
        public DPostulante() { }
       

        public String Registrar(Postulante postulante)
        {
            try
            {
                using (var context = new BDEFEntities())
                {
                    context.Postulante.Add(postulante);
                    Postulante_Ingresante = postulante;
                    context.SaveChanges();
                    DCorreo correo = new DCorreo();
                    correo.EnviarCorreo(postulante.Correo, "Registro Exitoso en WanderJobs", "Usted ha sido registrado con éxito en nuestro sistema. Desde ahora ya puedes ver las multiples ofertas de empleo y postularte a la que desees!!");
                }
                return "Los datos fueron guardados con exito, se ha enviado un correo a su cuenta de gmail para validar su registro...";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        public static void PostulanteExistente(Usuario usuario)
        {
            using (var context = new BDEFEntities())
            {
                Postulante PostulanteEncontrado = context.Postulante.FirstOrDefault(e => e.UsuarioID == usuario.UsuarioID);
                Postulante_Ingresante = PostulanteEncontrado;
                
                context.SaveChanges();
            }
        }
        public String Modificar(Postulante postulante)
        {
            try
            {
                using (var context = new BDEFEntities())
                {
                    Postulante portuTemp = context.Postulante.Find(DUsuario.Usuario_Postulante.UsuarioID);
                    portuTemp.Nombre = postulante.Nombre;
                    portuTemp.UsuarioID = portuTemp.UsuarioID;
                    portuTemp.Foto = postulante.Foto;
                    portuTemp.CV = postulante.CV;  
                    portuTemp.Correo = postulante.Correo;
                    portuTemp.Telefono = postulante.Telefono;
                    portuTemp.FechaNacimiento = postulante.FechaNacimiento;
                    portuTemp.Direccion = postulante.Direccion;
                    context.SaveChanges();
                    DCorreo correo = new DCorreo();
                    correo.EnviarCorreo(postulante.Correo, "Registro Actualizado", "Estimado postulante, su registro ha sido modificado satisfactoriamente");

                }
                return "Registro modificado exitosamente";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        public List<Postulante> ListarTodo()
        {
            List<Postulante> lista = new List<Postulante>();
            try
            {
                using (var context = new BDEFEntities())
                {
                    lista = context.Postulante.ToList();
                    context.SaveChanges();
                }
                return lista;
            }
            catch (Exception ex)
            {
                return lista;
            }
        }

    }
}
