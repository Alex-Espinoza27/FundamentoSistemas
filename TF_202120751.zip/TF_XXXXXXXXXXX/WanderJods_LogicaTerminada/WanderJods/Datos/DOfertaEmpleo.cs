﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class DOfertaEmpleo
    {
        public DOfertaEmpleo() { }
        public String CrearOfertaEmpleo(Oferta_Empleo Oferta)
        {
            try
            {
                using (var context = new BDEFEntities())
                {
                    context.Oferta_Empleo.Add(Oferta);
                    context.SaveChanges();
                }
                return "Oferta de empleo registrada con éxito.";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public String EliminarOferta(int id)
        {
            try
            {
                using (var context = new BDEFEntities())
                {
                    Oferta_Empleo OfertaEmpleoTemp = context.Oferta_Empleo.Find(id);
                    context.Oferta_Empleo.Remove(OfertaEmpleoTemp);
                    context.SaveChanges();
                }
                return "La oferta ha sido Eiminado exitosamente";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        public String inhabilitarPuesto(int id)
        {
            try
            {
                using (var context = new BDEFEntities())
                {
                    Oferta_Empleo OfertaEmpleoTemp = context.Oferta_Empleo.Find(id);
                    OfertaEmpleoTemp.ind_Activo = false;
                    context.SaveChanges();
                }
                return "La oferta ha sido cambiado a estado no solicitable";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public List<Oferta_Empleo> ListarTodo()
        {
            List<Oferta_Empleo> oferta_Empleos = new List<Oferta_Empleo>();
            try
            {
                using (var context = new BDEFEntities())
                {
                    oferta_Empleos = context.Oferta_Empleo.ToList();
                }
                return oferta_Empleos;
            }
            catch (Exception ex)
            {
                return oferta_Empleos;
            }
        }
    }
}
