﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;


namespace Datos
{
    public class DUsuario
    {
        public DUsuario() { }

        // MODIFICADO 
        public static Usuario Usuario_Empresa;
        public static Usuario Usuario_Postulante;
        
        public bool ExisteUsuario(Usuario usuario)
        {
            using (var context = new BDEFEntities())
            {
                var usuarioEncontrado = context.Usuario.FirstOrDefault(e => e.Nombre_usuario == usuario.Nombre_usuario && 
                                                                                e.Contrasena == usuario.Contrasena &&
                                                                                e.TipoUsuario == usuario.TipoUsuario);
                if (usuarioEncontrado == null)
                {
                    return false;
                }
                else
                {
                    if(usuarioEncontrado.TipoUsuario == "Postulante")
                    {
                        Usuario_Postulante = usuarioEncontrado;
                        DPostulante.PostulanteExistente(Usuario_Postulante);
                    }
                    else
                    {
                        Usuario_Empresa = usuarioEncontrado;
                        DEmpresa.EmpresaExistente(Usuario_Empresa);
                    }
                    return true;
                }
            }
        }
        public bool ExisteNombreUsuario(String nombre)
        {
            using (var context = new BDEFEntities())
            {
                var usuarioEncontrado = context.Usuario.FirstOrDefault(e => e.Nombre_usuario == nombre);
               
                if (usuarioEncontrado == null)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }
        public String Registrar(Usuario usuario)
        {
            try
            {
                using (var context = new BDEFEntities())
                {
                    context.Usuario.Add(usuario);
                    context.SaveChanges();
                }
                return "Registrado exitosamente";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        /*
          public String Eliminar(int id)
         {
             try
             {
                 using (var context = new BDEFEntities())
                 {
                     Usuario UsuarioTemp = context.Usuario.Find(id);
                     context.Usuario.Remove(UsuarioTemp);
                     context.SaveChanges();
                 }
                 return "Eiminado exitosamente";
             }
             catch (Exception ex)
             {
                 return ex.Message;
             }
         }
         */
        public List<Usuario> ListarUsuarios()
        {
            List<Usuario> usuarios = new List<Usuario>();
            try
            {
                using (var context = new BDEFEntities())
                {
                    usuarios = context.Usuario.ToList();
                    context.SaveChanges();
                }
                return usuarios;
            }
            catch (Exception ex)
            {
                return usuarios;
            }
        }
       
    }
}
