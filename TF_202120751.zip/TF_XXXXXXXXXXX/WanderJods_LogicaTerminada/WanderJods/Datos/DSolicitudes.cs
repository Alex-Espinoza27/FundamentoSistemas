﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class DSolicitudes
    {
        public DSolicitudes() { }

        public String RegistrarSolicitud(Solicitudes soli)
        {
            try
            {
                using (var context = new BDEFEntities())
                {
                    var solicitudExiste = context.Solicitudes.FirstOrDefault(e => e.PostulanteID == soli.PostulanteID &&
                                                                            e.OfertaID == soli.OfertaID);
                    
                    if (solicitudExiste == null)
                    {
                        context.Solicitudes.Add(soli);
                        context.SaveChanges();

                        var postulanteEmail = context.Postulante.FirstOrDefault(p => p.PostulanteID == soli.PostulanteID)?.Correo;

                        if (!string.IsNullOrEmpty(postulanteEmail))
                        {
                            // Envío de correo
                            DCorreo correo = new DCorreo();
                            correo.EnviarCorreo(postulanteEmail, "Solicitud Enviada", "Estimado postulante de WanderJobs su solicitud ha sido enviada con éxito. Pronto se le estara enviando un nuevo correo...");
                        }
                        return "Su solicitud ha sido enviada, revise su cuenta Gamil para enterarse de las novedades!!";
                    }
                    else
                    {
                        return "Solicitud ya fue enviada";
                    }
                }
                
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        public List<Solicitudes> ListarTodo()
        {
            List <Solicitudes> lista = new List<Solicitudes>();
            try
            {
                using (var context = new BDEFEntities())
                {
                    lista = context.Solicitudes.ToList();
                    context.SaveChanges();
                }
                return lista;
            }
            catch (Exception ex)
            {
                return lista;
            }
        }
        public String AceptarSolicitud(Solicitudes soliAceptado)
        {
            try
            {
                using (var context = new BDEFEntities())
                {
                    Datos.Solicitudes soliTemp = context.Solicitudes.Find(soliAceptado.SolicitudID);
                    soliTemp.EstadoSolicitud = "Aceptado";

                    Oferta_Empleo ofertaOcupada = context.Oferta_Empleo.Find(soliAceptado.OfertaID);
                    ofertaOcupada.ind_Activo = false;
                    
                    Datos.Historial_Solicitudes historialSoli = context.Historial_Solicitudes.Find(soliAceptado.SolicitudID);
                    historialSoli.EstadoSolicitud = "Aceptado";

                    context.SaveChanges();

                    var postulanteEmail = context.Postulante.FirstOrDefault(p => p.PostulanteID == soliTemp.PostulanteID)?.Correo;
                    
                    if (!string.IsNullOrEmpty(postulanteEmail))
                    {
                        DCorreo correo = new DCorreo();
                        correo.EnviarCorreo(postulanteEmail, "Solicitud Aceptada", "Estimado postulante de WanderJobs, su solicitud ha sido aceptada y validada con éxito.");
                    }

                }
                return "Solicitud Aceptada";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        public byte[] VerCVPostulante(int id)
        {
            byte[] CV;
            using (var context = new BDEFEntities())
            {
                CV = (byte[])context.Postulante.Find(id).CV;
                context.SaveChanges();
            }
            return CV;
        }
 
    }
}
