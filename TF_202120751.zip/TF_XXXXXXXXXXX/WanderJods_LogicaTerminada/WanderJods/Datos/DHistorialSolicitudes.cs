﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class DHistorialSolicitudes
    {
        public  DHistorialSolicitudes() { }

        public void RegistrarHistorial(Historial_Solicitudes historial)
        {
            using (var context = new BDEFEntities())
            {
                context.Historial_Solicitudes.Add(historial);
                context.SaveChanges();
            }
        }

        public String EliminarHistorial(int id)
        {
            try
            {
                using (var context = new BDEFEntities())
                {
                    Historial_Solicitudes historialTemp = context.Historial_Solicitudes.Find(id);
                    context.Historial_Solicitudes.Remove(historialTemp);
                    context.SaveChanges();
                }
                return "Se elimino correctamente el historial";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public List<Historial_Solicitudes> ListarTodo()
        {
            List<Historial_Solicitudes> historiales = new List<Historial_Solicitudes>();
            try
            {
                using (var context = new BDEFEntities())
                {
                    historiales = context.Historial_Solicitudes.ToList();
                }
                return historiales;
            }
            catch (Exception ex)
            {
                return historiales;
            }
        }
    }
}
