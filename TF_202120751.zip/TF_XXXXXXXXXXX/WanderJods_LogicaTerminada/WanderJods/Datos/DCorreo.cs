﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class DCorreo
    {
        private string fromAddress = "WanderJobsOficial@gmail.com";
        private string password = "ovil itgk buak ttoz";

        public void EnviarCorreo(string toAddress, string subject, string body)
        {
            using (MailMessage mailMessage = new MailMessage())
            {
                mailMessage.To.Add(toAddress);
                mailMessage.From = new MailAddress(fromAddress, "WanderJobs: Sistema de busqueda de empleos");
                mailMessage.Subject = subject;
                mailMessage.Body = body;
                mailMessage.IsBodyHtml = false;

                using (SmtpClient smtpClient = new SmtpClient("smtp.gmail.com"))
                {
                    smtpClient.UseDefaultCredentials = false;
                    smtpClient.Credentials = new NetworkCredential(fromAddress, password);
                    smtpClient.Port = 587;
                    smtpClient.EnableSsl = true;

                    try
                    {
                        smtpClient.Send(mailMessage);
                    }

                    catch (SmtpException ex)
                    {

                        Console.WriteLine("Error al enviar el correo: " + ex.Message);
                    }
                }
            }
        }
    }
}
