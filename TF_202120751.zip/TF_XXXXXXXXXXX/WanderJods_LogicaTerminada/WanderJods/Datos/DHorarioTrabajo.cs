﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class DHorarioTrabajo
    {
        public DHorarioTrabajo() { }
        public String RegistrarHorario(Horario_trabajo horario)
        {
            try
            {
                using (var context = new BDEFEntities())
                {
                    context.Horario_trabajo.Add(horario);
                    context.SaveChanges();
                }
                return "Registro exitoso";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        public List<Horario_trabajo> ListarTodo()
        {
            List<Horario_trabajo> horario_Trabajos = new List<Horario_trabajo>();
            try
            {
                using (var context = new BDEFEntities())
                {
                    horario_Trabajos = context.Horario_trabajo.ToList();
                }
                return horario_Trabajos;
            }
            catch (Exception ex)
            {
                return horario_Trabajos;
            }
        }

        public String Eliminar(int id)
        {
            try
            {
                using (var context = new BDEFEntities())
                {
                    Horario_trabajo horarioTemp = context.Horario_trabajo.Find(id);
                    context.Horario_trabajo.Remove(horarioTemp);
                    context.SaveChanges();
                }
                return "Eiminado exitosamente";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
    }
}
