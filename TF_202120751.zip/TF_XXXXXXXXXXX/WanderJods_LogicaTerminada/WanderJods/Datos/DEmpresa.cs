﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class DEmpresa
    {
        public static Empresa Empresa_Ingresante;
        public DEmpresa() { }

        public String RegistrarEmpresa(Empresa empresa)
        {
            try
            {
                using (var context = new BDEFEntities())
                {
                    context.Empresa.Add(empresa);
                    Empresa_Ingresante = empresa;
                    context.SaveChanges();
                    DCorreo correo = new DCorreo();
                    correo.EnviarCorreo(empresa.Correo, "Registro exitoso", "Estimado empleador, su registro ha sido completado satisfactoriamente, ahora es miembro de WanderJobs...");
                }
                return "Empresa registrada con éxito, verifique su correo gmail para confirmar su registro...";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        public static void EmpresaExistente(Usuario usuario)
        {
            using (var context = new BDEFEntities())
            {
                Empresa EmpresaEncontrado = context.Empresa.FirstOrDefault(e => e.UsuarioID == usuario.UsuarioID);
                Empresa_Ingresante = EmpresaEncontrado;
                context.SaveChanges();
            }
        }

        public String ActualizarDatos(Empresa empresa)
        {
            try
            {
                using (var context = new BDEFEntities())
                {
                    Empresa EmppresaTemp = context.Empresa.Find(DEmpresa.Empresa_Ingresante.EmpresaID);
                    EmppresaTemp.Nombre_Empresa = empresa.Nombre_Empresa;
                    EmppresaTemp.Correo = empresa.Correo;
                    EmppresaTemp.Telefono = empresa.Telefono;
                    EmppresaTemp.Rubro = empresa.Rubro;
                    EmppresaTemp.RUC = empresa.RUC;
                    context.SaveChanges();
                    DCorreo correo = new DCorreo();
                    correo.EnviarCorreo(empresa.Correo, "Registro Actualizado", "Estimado empleador, su registro ha sido modificado satisfactoriamente");
                }
                return "Actualizado exitosamente";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        public List<Empresa> ListarTodo()
        {
            List<Empresa> lista = new List<Empresa>();
            try
            {
                using (var context = new BDEFEntities())
                {
                    lista = context.Empresa.ToList();
                    context.SaveChanges();
                }
                return lista;
            }
            catch (Exception ex)
            {
                return lista;
            }
        }

    }
}
